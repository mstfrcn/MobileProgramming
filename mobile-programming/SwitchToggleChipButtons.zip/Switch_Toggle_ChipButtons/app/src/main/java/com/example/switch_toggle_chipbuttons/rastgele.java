package com.example.switch_toggle_chipbuttons;

import java.util.Random;

public class rastgele {
    static String resim(){
        String yol="@drawable/d";
        Random r = new Random();
        yol+=Integer.toString(r.nextInt(6)+1);
        return yol;
    }
}
