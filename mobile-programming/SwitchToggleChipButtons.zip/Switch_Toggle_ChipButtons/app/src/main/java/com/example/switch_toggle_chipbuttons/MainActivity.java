package com.example.switch_toggle_chipbuttons;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.google.android.material.chip.Chip;

public class MainActivity extends AppCompatActivity {

    Switch s1;
    TextView textView, textView2, textView3;
    ToggleButton tb;
    Button button, button2;
    Chip c1,c2,c3;
    ImageView iv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);

        s1 = (Switch) findViewById(R.id.switch1);
        s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (s1.isChecked()) textView.setText("switch acik");
                else textView.setText("switch kapali");
            }
        });
        textView2 = (TextView) findViewById(R.id.textView2);

        tb = (ToggleButton) findViewById(R.id.toggleButton2);
        tb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

            }
        });

        textView3 = (TextView) findViewById(R.id.textView3);
        c1 = (Chip) findViewById(R.id.chip4);
        c2 = (Chip) findViewById(R.id.chip5);
        c3 = (Chip) findViewById(R.id.chip6);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView3.setText("");
                String sonuc="";
                if (c1.isChecked()) sonuc+="Turkce Secildi - ";
                if (c2.isChecked()) sonuc+="Ingilizce Secildi - ";
                if (c3.isChecked()) sonuc+="Almanca Secildi - ";
                textView3.setText(sonuc);
            }
        });

        iv = (ImageView) findViewById(R.id.imageView2);
        button2 = (Button) findViewById(R.id.button2);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int imageResources = getResources().getIdentifier(rastgele.resim(),null,getPackageName());
                Drawable res = getResources().getDrawable(imageResources);
                iv.setImageDrawable(res);




            }
        });

    }
}