package com.example.h3_hesap_makinesi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText sayi1;
    EditText sayi2;
    TextView sonuc;
    Button topla,cikart,carp,bol,temizle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sayi1 = (EditText) findViewById(R.id.plainText1);
        sayi2 = (EditText) findViewById(R.id.plainText2);
        sonuc = (TextView) findViewById(R.id.textView);

        topla = (Button) findViewById(R.id.buttonTopla);
        cikart = (Button) findViewById(R.id.buttonCikart);
        carp =(Button)  findViewById(R.id.buttonCarp);
        bol = (Button) findViewById(R.id.buttonBol);
        temizle =(Button)  findViewById(R.id.buttonTemizle);

        topla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int s1 = Integer.parseInt(sayi1.getText().toString());
                int s2 = Integer.parseInt(sayi2.getText().toString());
                sonuc.setText(Integer.toString(s1+s2));
            }
        });
        cikart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int s1 = Integer.parseInt(String.valueOf(sayi1.getText()));
                int s2 = Integer.parseInt(String.valueOf(sayi2.getText()));
                sonuc.setText(s1-s2);
            }
        });
        carp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int s1 = Integer.parseInt(String.valueOf(sayi1.getText()));
                int s2 = Integer.parseInt(String.valueOf(sayi2.getText()));
                sonuc.setText(String.valueOf(s1*s2));
            }
        });
        bol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float s1 = (float)Integer.parseInt(String.valueOf(sayi1.getText()));
                float s2 = (float)Integer.parseInt(String.valueOf(sayi2.getText()));
                sonuc.setText(String.valueOf(s1/s2));
            }
        });
        temizle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sayi1.setText("");
                sayi2.setText("");
                sonuc.setText("");
            }
        });



    }
}