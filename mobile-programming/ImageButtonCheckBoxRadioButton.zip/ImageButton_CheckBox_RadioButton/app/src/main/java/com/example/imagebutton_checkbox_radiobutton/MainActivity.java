package com.example.imagebutton_checkbox_radiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ImageButton ig;
    CheckBox cb1;
    RadioButton rd1, rd2, rd3, rd4;
    Button button;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ig = (ImageButton) findViewById(R.id.imageButton);
        ig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Image butona tiklandi");

            }
        });

        cb1 = (CheckBox) findViewById(R.id.checkBox);
        cb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(cb1.isChecked()){
                    System.out.println("CheckBox Secildi");
                }

            }
        });
        rd1 = (RadioButton) findViewById(R.id.rd1);
        rd2 = (RadioButton) findViewById(R.id.rd2);
        rd3 = (RadioButton) findViewById(R.id.rd3);
        rd4 = (RadioButton) findViewById(R.id.rd4);
        button = (Button) findViewById(R.id.button);
        textView = (TextView) findViewById(R.id.textView);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rd1.isChecked()) textView.setText("A Sikki Secildi");
                if (rd2.isChecked()) textView.setText("B Sikki Secildi");
                if (rd3.isChecked()) textView.setText("C Sikki Secildi");
                if (rd4.isChecked()) textView.setText("D Sikki Secildi");
            }
        });

    }
}