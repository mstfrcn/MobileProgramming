package com.example.webview_slider;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SeekBar seekBarTransparan,seekBarRed,seekBarGreen,seekBarBlue;
    Button button;
    TextView textView;
    int renk, r,g,b=0;
    int transparan = 255;
    String srenk;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);
        textView = (TextView) findViewById(R.id.textView2);
        seekBarTransparan = (SeekBar) findViewById(R.id.seekBarTransparan);
        seekBarRed = (SeekBar) findViewById(R.id.seekBarRed);
        seekBarGreen = (SeekBar) findViewById(R.id.seekBarGreen);
        seekBarBlue = (SeekBar) findViewById(R.id.seekBarBlue);

        seekBarTransparan.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean c) {
                transparan = i;
                renk = Color.argb(transparan,r,g,b);
                button.setBackgroundColor(renk);
                srenk = Integer.toString(renk);
                textView.setText(srenk);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        seekBarRed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean c) {
                r = i;
                renk = Color.argb(transparan,r,g,b);
                button.setBackgroundColor(renk);
                srenk = Integer.toString(renk);
                textView.setText(srenk);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        seekBarGreen.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean c) {
                g = i;
                renk = Color.argb(transparan,r,g,b);
                button.setBackgroundColor(renk);
                srenk = Integer.toString(renk);
                textView.setText(srenk);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        seekBarBlue.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean c) {
                b = i;
                renk = Color.argb(transparan,r,g,b);
                button.setBackgroundColor(renk);
                srenk = Integer.toString(renk);
                textView.setText(srenk);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }
}