package com.example.sayi_tahmin_oyunu;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button buton,yeniOyun;
    EditText tahmin;
    TextView sonuc;
    int hak,tutulanSayi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buton = (Button) findViewById(R.id.button);
        yeniOyun = (Button) findViewById(R.id.buttonYenile);
        tahmin = (EditText) findViewById(R.id.editText);
        sonuc = (TextView) findViewById(R.id.textView);
        hak = 0;

        Random r = new Random();
        tutulanSayi = r.nextInt(10);

        buton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int tah = Integer.parseInt(tahmin.getText().toString());
                if (tutulanSayi == tah){
                    sonuc.setTextColor(Color.GREEN);
                    sonuc.setText("Tebrikler Dogru Bildiniz. \nTahmin sayiniz "+hak);
                }
                else if(tutulanSayi < tah){
                    sonuc.setTextColor(Color.YELLOW);
                    sonuc.setText("Daha kucuk Sayi Giriniz");
                    hak++;
                }else{
                    sonuc.setTextColor(Color.BLUE);
                    sonuc.setText("Daha Buyuk Sayi Giriniz");
                    hak++;
                }
                tahmin.setText("");
            }
        });
        yeniOyun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hak=0;
                tutulanSayi = r.nextInt(10);
                sonuc.setText("");
            }
        });
    }
}